package com.hainiuxy.test;


import com.sun.javaws.IconUtil;

public class Test03 {
    /*
     *    超哥   我这个为什么不对呢？  看半天不知道为什么
     * */

    public static void main(String[] args) {
    //定义数组
    int[] a = {11, 33, 55, 77};
    int[] b = {22, 44, 66, 88};
    //获取数组a 和 b总长度
    int length =a.length+b.length;
//        System.out.println(length);
    int[] c =new int [length];

    int ccount =0;
    //取出a ， b数组元素并存入c 数组中

        //取出a数组
        for (int i = 0; i < a.length; i++) {
            c[ccount] = a[i];
            i++;
            ccount++;

        }
        System.out.println(ccount);
        //取出b数组
        for (int i = 0; i < b.length; i++) {
            c[ccount] = b[i];
            i++;
            ccount++;

        }
        System.out.println(ccount);


    //取出c数组中元素
        for (int i = 0; i < c.length; i++) {
            System.out.println(c[i]);
        }



    }
}
