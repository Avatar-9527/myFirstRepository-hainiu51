package com.hainiuxy.test;

public class Test04 {
    public static void main(String[] args) {
    //定义变量   可以确定除了第一天桃子为奇数   后面所以都为偶数  可以使用int
    int tao = 1;

    int day = 10;
        //计算数量  从第十天剩下一个桃子开始  反推
        for (int i = 0; i < day; i++) {
            tao = (tao+1)*2 ;
//            System.out.println(tao);
        }

        System.out.println("第一天一共摘了："+tao+"个桃子");


    }
}
