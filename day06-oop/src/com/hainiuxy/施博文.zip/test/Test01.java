package com.hainiuxy.test;

public class Test01 {
    public static void main(String[] args) {

        //开始高度
        double start = 100;
        //计数
        int count =0;
        //总路程
        double all=0;

        while(start>0){
            //计算总路程
            /*
            *   此总路程计算公司不对
            * */
            all = start*2 +all;
            //计算每次反弹的最高点
            start = start/2;


            count++;
            if(count==10){
                System.out.println(count);
                System.out.println("第十次落地反弹的高度是："+start);
                System.out.println("第十次最高的，经过的总路程是："+all);
            }


        }





    }

}
