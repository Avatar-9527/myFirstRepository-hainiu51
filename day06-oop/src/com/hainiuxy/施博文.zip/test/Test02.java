package com.hainiuxy.test;

public class Test02 {
    public static void main(String[] args) {
        double[] score = {77.1, 88.1, 76.1, 56.1, 87.1, 98.1, 55.1, 94.1, 39.1, 96.1};
        //定义变量
        double num =0;
        double max =score[0];
        double min =score[0];


        //遍历数组
        for (int i = 0; i < score.length; i++) {
            //计算总分
            num = num + score[i];
            //求最高分
            if(max <score[i]){

                max = score[i];

            }
            //求最低分
            if(min >score[i]){

                min = score[i];
            }
//            System.out.println(score[i]);
        }
        //计算平均分
        double pnum = num / score.length;
        System.out.println("平均分是："+pnum);
        System.out.println("最高分是："+max);
        System.out.println("最低分是："+min);


    }
}
